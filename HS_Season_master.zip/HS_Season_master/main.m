% This script provides data description and analysis demonstration
% The data and mask can be found in the corresponded subfold
% Call functions from #functions#

% Please contact Dr Sheng Hu, hushengustc@163.com
% this analysis need Libsvm toolbox (https://www.csie.ntu.edu.tw/~cjlin/libsvm/)
addpath(genpath('./NIfTI_20140122'))
addpath(genpath('./gifti-main'))
%% SVM in parcel level
%%
% add path
addpath ./SVM_Train
addpath ./functions
%-------------------parcel level SVM train: all samples--------------------
% load feature and label
load feature_fALFF.mat          
load label_fALFF.mat

% parcel level SVM train
feature = feature_fALFF;
label = label_fALFF;
nfold=10;
Jloop = 0;
[parcels_acu_fALFF,nfold_parsPredLabel,nfoldTestLabel] = parcelLevel_SVM(feature,label,nfold,Jloop);

% the parcel-level importance
permute = 1000;
parcels_acu = parcels_acu_fALFF;
pars_changeScoresfALFF_perm = parcel_importance(parcels_acu,permute,feature,label);
%-----------------------parcel level SVM train: end------------------------

%----------------------parcel level SVM train: Male------------------------
 % load feature and label
load feature_fALFF_male.mat         
load label_fALFF_male.mat

% parcel level SVM train
feature = feature_fALFF_male;
label = label_fALFF_male;
nfold=10;
Jloop = 0;
[parcels_acu_fALFF_male,nfold_parsPredLabel_male,nfoldTestLabel_male] = parcelLevel_SVM(feature,label,nfold,Jloop);

% the parcel-level importance
permute = 1000;
parcels_acu = parcels_acu_fALFF_male;
pars_changeScoresfALFF_perm_male = parcel_importance(parcels_acu,permute,feature,label);
save('pars_changeScoresfALFF_perm_male')
%-----------------------parcel level SVM train: end------------------------

%----------------------parcel level SVM train: Female----------------------
% load feature and label
load feature_fALFF_female.mat          
load label_fALFF_female.mat

% parcel level SVM train: female sample
feature = feature_fALFF_female;
label = label_fALFF_female;
nfold=10;
Jloop = 0;
[parcels_acu_fALFF_female,nfold_parsPredLabel_female,nfoldTestLabel_female] = parcelLevel_SVM(feature,label,nfold,Jloop);

% the parcel-level importance
permute = 1000;
parcels_acu = parcels_acu_fALFF_female;
pars_changeScoresfALFF_perm_female = parcel_importance(parcels_acu,permute,feature,label);
%-----------------------parcel level SVM train: end------------------------

% map to surface
addpath ./Masks
changeScorefALFF_mean = mean(pars_changeScoresfALFF_perm,2);
MMP_surf_label_file = 'fsaverage_lh_HCP-MMP1.label.gii'; % (lh or rh)
func_label = 'ChangeScore';
output_DIR = './SVM_Train';
map_to_mmp_surf(MMP_surf_label_file,changeScorefALFF_mean,func_label,output_DIR)

%% SVM in network level
%%
% add path
addpath ./SVM_Train
addpath ./functions
addpath ./Masks
%-------------------network level SVM train: all samples--------------------
load feature_fALFF.mat          % load feature and label
load label_fALFF.mat
load MMP_network.mat            % load network information

% network level SVM train
feature = feature_fALFF;
label = label_fALFF;
net_label = MMP_network;
nfold = 10;
Jloop = 0;
[nets_Acu,nfold_netsPredLabel,nfoldTestLabel] = networkLevel_SVM(net_label,feature,label,nfold,Jloop);

% network importance
permute = 1000;
net_change_score_perm = net_importance(nets_Acu,net_label,permute,feature,label);
%----------------------network level SVM train: end------------------------

%---------------------network level SVM train: Male------------------------
load feature_fALFF_male.mat     % load feature and label
load label_fALFF_male.mat
load MMP_network.mat            % load network information

% network level SVM train
feature = feature_fALFF_male;
label = label_fALFF_male;
net_label = MMP_network;
nfold = 10;
Jloop = 0;
[nets_Acu_male,nfold_netsPredLabel_male,nfoldTestLabel_male] = networkLevel_SVM(net_label,feature,label,nfold,Jloop);

% network importance
permute = 1000;
net_change_score_perm_male = net_importance(nets_Acu_male,net_label,permute,feature,label);
%----------------------network level SVM train: end------------------------

%---------------------network level SVM train: Female----------------------
load feature_fALFF_female.mat     % load feature and label
load label_fALFF_female.mat
load MMP_network.mat            % load network information

feature = feature_fALFF_female;
label = label_fALFF_female;
net_label = MMP_network;
nfold = 10;
Jloop = 0;
[nets_Acu_female,nfold_netsPredLabel_female,nfoldTestLabel_female] = networkLevel_SVM(net_label,feature,label,nfold,Jloop);

% network importance
permute = 1000;
net_change_score_perm_female = net_importance(nets_Acu_female,net_label,permute,feature,label);
%----------------------network level SVM train: end------------------------

% randome network importance: shulff parcels across the whole brain and reassign
% each network
feature = feature_fALFF;
label = label_fALFF;
shull_ture = 1;
changeScore_done = 1;
outputDIR = './SVM_Train';
[net_label_Shuff,net_Acu_Shuff,net_change_score_perm_Shuff] = controlNetwork(MMP_network,feature,label,shull_ture,changeScore_done,outputDIR);

%% The distribution of classifying accuracy (network-level)
%%
% add path
addpath ./SVM_Train
addpath ./functions
addpath ./Masks

% load feature and label
load feature_fALFF.mat
load label_fALFF.mat

% load network information
load MMP_network.mat

feature = feature_fALFF;
label = label_fALFF;
net_label = MMP_network;
permute = 1000;
net_distributAccu = bootstrapAccu_nets(net_label,permute,feature,label);

%% Associations between Parcel-level change score and gene expression
%%
% add path
addpath ./functions
addpath ./GeneprocessedData
addpath ./SVM_Train
addpath ./PLS_Pars
% set path
outputdir = './PLS_Pars';

% load parcel-level change score and gene expression (based on MMP atlas)
load('pars_ChangeScorefALFF_Perm.mat','changeScoresfALFF_perm')
load('100DS360scaledRobustSigmoidNSGRNAseqQC1LRcortex_ROI_NOdistCorrEuclidean.mat')
load('GeneSymbol.mat')

ind_gene = find(~isnan(parcelExpression(:,2))); % index of nonNaN in parcel gene expression

parcelExpression1 = parcelExpression(ind_gene,2:end); % gene expression excluded with NaN

% ===============calculate weight for each gene=====================
% ((gene expression as predictor, Z map of change score as response valuable)
pars_changeScores = mean(changeScoresfALFF_perm,2); % excluded NaN in parcel-level change score
pars_changeScores1 = pars_changeScores(ind_gene);

chs_thd = 0:0.01:0.2;
PLS_Par_Stat = cell(length(chs_thd),1);
PLS_R = [];
for i = 1:length(chs_thd)
    thd_ind = find(pars_changeScores1 > chs_thd(i));
    Change_Score_thd = pars_changeScores1(thd_ind);
    pExpression_thd = parcelExpression1(thd_ind,:);
    PLS_Par_Stat{i} = PLS_bootstrap_hs(pExpression_thd,GeneSymbol,Change_Score_thd);
    PLS_R = [PLS_R,PLS_Par_Stat{i}.R_Squ];
end
save(fullfile(outputdir,'PLS_Par_Stat.mat'),'PLS_Par_Stat')
save(fullfile(outputdir,'PLS_R.mat'),'PLS_R')

% stat PLS
thd_ind_11 = find(pars_changeScores1 > chs_thd(11));
thd_ind_less11 = find(pars_changeScores1 < chs_thd(11));
Change_Score_thd11 = pars_changeScores1(thd_ind_11);
pExpression_thd11 = parcelExpression1(thd_ind_11,:);
pExpression_thdless11 = parcelExpression1(thd_ind_less11,:);
PLS_calculate_stats_hs(pExpression_thd11,pExpression_thdless11,Change_Score_thd11,outputdir)

% ==========specific analysis for pls of cortex=========== 
addpath ./GeneprocessedData
addpath ./PLS_Pars
addpath ./functions

load('PLS_Par_Stat.mat')
load('Candidate_gene.mat')

PLS = PLS_Par_Stat{11};

disease_GeneName = {'Depression_gene','Bipolar_gene','Autism_gene',...
  'Schizophrenia_gene','Intellectual_disability_gene'};
disease_GeneName = disease_GeneName';

CandGene_ER = zeros(length(disease_GeneName),1);
CandGene_P = zeros(length(disease_GeneName),1);
for i = 1:length(disease_GeneName)
    eval(['CandGene = Candidate_gene.',disease_GeneName{i},';'])
    [p,ER] = PLS_candidate_genes_ER(PLS.pls1,CandGene);
    CandGene_ER(i) = ER;
    CandGene_P(i) = p;
end
CandGene_q = mafdr(CandGene_P,'BHFDR',true);
logFDR = -log10(CandGene_q);

%% Associate Change score with neurotranmiter
%%
% add path
addpath ./functions
addpath ./GeneprocessedData
addpath ./SVM_Train

% load parcel-level change score and gene expression (based on MMP atlas)
load('pars_ChangeScorefALFF_Perm.mat','changeScoresfALFF_perm')
load('pars_ChangeScorefALFF_Perm_male.mat','male_changeScoresfALFF_perm')
load('pars_ChangeScorefALFF_Perm_female.mat','female_changeScoresfALFF_perm')
load('100DS360scaledRobustSigmoidNSGRNAseqQC1LRcortex_ROI_NOdistCorrEuclidean.mat')

ind_gene = find(~isnan(parcelExpression(:,2))); % index of nonNaN in parcel gene expression

% change score exclude NaN
changeScore = mean(changeScoresfALFF_perm,2);
changeScore1 = changeScore(ind_gene);

male_changeScores = mean(male_changeScoresfALFF_perm,2);
female_changeScores = mean(female_changeScoresfALFF_perm,2);

male_changeScores1 = male_changeScores(ind_gene);
female_changeScores1 = female_changeScores(ind_gene);

% thd the change score
chs_thd = 0:0.01:0.2;

% thd change score with 0.1 (chs_thd(11))
thd_ind = find(changeScore1 > chs_thd(11));
male_changeScores1_thd = male_changeScores1(thd_ind);
female_changeScores1_thd = female_changeScores1(thd_ind);
changeScores1_thd = changeScore1(thd_ind);

% mmp template exclude NaN and thd11
mmp_atl = 1:360;
mmp_atl1 = mmp_atl(ind_gene);
mmp_atl1_thd = mmp_atl1(thd_ind);

% extract neurotransmiter value based on thd mmp atalas
addpath ./PETatlas_NS
addpath ./Masks

PET_PATH = './PETatlas_NS';
mmp_temp = 'MNI_Glasser_HCP_v2.0.nii.gz';

% mmp_temp = 'MNI_Glasser_HCP_v1.0_3mm.nii.gz';
mmp_nifti = load_untouch_nii(mmp_temp);
mmp_img = mmp_nifti.img;

PET_DIR = dir(fullfile(PET_PATH,'*.nii'));

PET_MMP_Value_ALL = extract_neurotran(PET_DIR,mmp_atl1_thd,mmp_img);

% Correlation between change score and neurotransmitter
[R_male,P_male] = corr(PET_MMP_Value_ALL,male_changeScores1_thd);
[R_female,P_female] = corr(PET_MMP_Value_ALL,female_changeScores1_thd);
[R_all,P_all] = corr(PET_MMP_Value_ALL,changeScores1_thd);
R_FM = [R_male,R_female];
q_male = mafdr(P_male,'BHFDR',true);
q_female = mafdr(P_female,'BHFDR',true);
q_all = mafdr(P_all,'BHFDR',true);
%% Associate Change score with neurosynth
%%
% add path
addpath ./functions
addpath ./SVM_Train
addpath ./Masks
addpath ./Neurosynth
addpath ./Neurosynth/terms

% Neurosynth and MMP atlas
Neurosynth_path = './Neurosynth/terms';
Neurosynth_dir = dir(fullfile(Neurosynth_path,'*.nii.gz'));
MMP_atla_file = 'MNI_Glasser_HCP_v1_2mm.nii.gz';
%---------Calulate Psychological probability using neurosynth----------%
MMP_nii = load_untouch_nii(MMP_atla_file);
MMP_img = MMP_nii.img;
msk_ind = find(MMP_img);
neusy_comb = zeros(size(MMP_img));
for i = 1:length(Neurosynth_dir)
    neusy_nii = load_untouch_nii(Neurosynth_dir(i).name);
    neusy_img = neusy_nii.img;
    neusy_img(neusy_img < 0) = 0;
    neusy_ind = find(neusy_img);
    neusy_img(neusy_ind) = 1;
    neusy_comb = neusy_comb + neusy_img;
end
neusy_comb = neusy_comb ./ length(Neurosynth_dir);
x = neusy_comb(msk_ind);
tonii = mat_to_nii(MMP_atla_file,x);
save_untouch_nii(tonii,'neurosyth_combined.nii.gz')
%------------------------------done------------------------------------%
Psychol_path = './Neurosynth';
Psychol_dir = dir(fullfile(Psychol_path,'*.nii.gz'));

% male 
load('pars_ChangeScorefALFF_Perm_male.mat','male_changeScoresfALFF_perm')
male_changeScoresfALFF_mean = mean(male_changeScoresfALFF_perm,2);
male_neusy_cs_all = cell(length(Psychol_dir),1);
male_R_pos = zeros(length(Psychol_dir),1);
male_P_pos = zeros(length(Psychol_dir),1);
for i = 1:length(Psychol_dir)
    neurosyth_file = Psychol_dir(i).name;
    [neusy_cs,R_pos,P_pos,Psychol_mmp] = changeScore_Corr_Neurosyth(male_changeScoresfALFF_mean,neurosyth_file,MMP_atla_file);
    male_neusy_cs_all{i} = neusy_cs;
    male_R_pos(i) = R_pos;
    male_P_pos(i) = P_pos;
end

% female
load('pars_ChangeScorefALFF_Perm_female.mat','female_changeScoresfALFF_perm')
female_changeScoresfALFF_mean = mean(female_changeScoresfALFF_perm,2);
female_neusy_cs_all = cell(length(Psychol_dir),1);
female_R_pos = zeros(length(Psychol_dir),1);
female_P_pos = zeros(length(Psychol_dir),1);
for i = 1:length(Psychol_dir)
    neurosyth_file = Psychol_dir(i).name;
    [neusy_cs,R_pos,P_pos,Psychol_mmp] = changeScore_Corr_Neurosyth(female_changeScoresfALFF_mean,neurosyth_file,MMP_atla_file);
    female_neusy_cs_all{i} = neusy_cs;
    female_R_pos(i) = R_pos;
    female_P_pos(i) = P_pos;
end

% all sample
load('pars_ChangeScorefALFF_Perm.mat','changeScoresfALFF_perm')
changeScoresfALFF_mean = mean(changeScoresfALFF_perm,2);
All_neusy_cs_all = cell(length(Psychol_dir),1);
All_R_pos = zeros(length(Psychol_dir),1);
All_P_pos = zeros(length(Psychol_dir),1);
for i = 1:length(Psychol_dir)
    neurosyth_file = Psychol_dir(i).name;
    [neusy_cs,R_pos,P_pos,Psychol_mmp] = changeScore_Corr_Neurosyth(changeScoresfALFF_mean,neurosyth_file,MMP_atla_file);
    All_neusy_cs_all{i} = neusy_cs;
    All_R_pos(i) = R_pos;
    All_P_pos(i) = P_pos;
end

% map psychological probability to MMP surfer
MMP_surf_label_file = 'fsaverage_rh_HCP-MMP1.label.gii'; % (lh or rh)
func_label = 'Psychol_Prob';
output_DIR = './Neurosynth';
map_to_mmp_surf(MMP_surf_label_file,Psychol_mmp,func_label,output_DIR)
