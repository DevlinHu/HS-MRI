function [nets_Acu,nfold_netsPredLabel,nfoldTestLabel] = networkLevel_SVM(net_label,feature,label,nfold,Jloop)
% This function is to classify the season in the network level
% Input:
%       net_label: the network index (each parcel identified with an index)
%       feature: the input feature extracted from functional parameters
%       label: the seasonal labels (Autumn = 1, Winter = 2, Spring = 3, Summer = 4)
%       nfold: nfold crossvalidation
% Output:
%        nets_acu: the accuracy of each network
%        nets_Predictlabel: predictory label for each network
%        nfoldTestLabel: the ture test label for all nfold 

% identify network
regiontoNet_id = zeros(size(feature,2),1);
region_id = zeros(size(feature,2),1);
for i = 1:size(feature,2)
    regiontoNet_id(i) = net_label{i,2};
    region_id(i) = net_label{i,1};
end
clear i

net_id = unique(regiontoNet_id);

indices = crossvalind('Kfold',label,nfold);

nets_Acu = zeros(length(net_id),1);
nfold_netsPredLabel = [];
nfoldTestLabel = [];
h = waitbar(0,'please wait..');
for i = 1:length(net_id)
    waitbar(i/length(net_id),h,[num2str(i),'/',num2str(length(net_id))])
    netIDX = find(regiontoNet_id == i);
    data = feature(:,region_id(netIDX));
    
    if Jloop == 0
       nfold_acu = zeros(nfold,1); 
    end
    
    for j = 1:nfold
        test_idx = (indices == j);
        train_idx = ~test_idx;
        
        train_data = data(train_idx,:);
        train_label = label(train_idx);
        
        [train_data,PS] = mapminmax(train_data',-1,1); % normaize data
        train_data = train_data';
        
        test_data = data(test_idx,:);
        test_label = label(test_idx);
        
        test_data = mapminmax('apply',test_data',PS);
        test_data = test_data';
        
        nfoldTestLabel = [nfoldTestLabel;test_label];
        %%% linear kernal
        [bestacc,bestc] = SVMcgForClass_NoDisplay_linear(train_label,train_data,-10,10,5,0.2);
        cmd = ['-t 0 ', '-h 0', ' -c ',num2str(bestc)];
        
        model = svmtrain(train_label,train_data, cmd);
        [predicted_label, accuracy, deci_value] = svmpredict(test_label,test_data,model);
        nfold_netsPredLabel = [nfold_netsPredLabel;predicted_label];
        if Jloop
            nfold_acu = accuracy(1);
            break
        else
            nfold_acu(j) = accuracy(1);
        end      
    end
    if Jloop
        nets_Acu(i) = nfold_acu;
    else
        nets_Acu(i) = mean(nfold_acu);
    end
end
close(h)