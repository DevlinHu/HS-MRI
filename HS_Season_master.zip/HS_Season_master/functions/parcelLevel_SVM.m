function [parcels_acu,nfold_parsPredLabel,nfoldTestLabel] = parcelLevel_SVM(feature,label,nfold,Jloop)
% This function is to classify the season in the parcel level
% Input:
%       feature: the input feature extracted from functional parameters
%       label: the seasonal labels (Autumn = 1, Winter = 2, Spring = 3, Summer = 4)
%       nfold: nfold crossvalidation
% Output:
%        parcels_acu: the accuracy of each parcel
%        nets_Predictlabel: predictory label for each parcel
%        nfoldTestLabel: the ture test label for all nfold 

indices = crossvalind('Kfold',label,nfold);
parcels_acu = zeros(length(feature(1,:)),1);
nfold_parsPredLabel = [];
nfoldTestLabel = [];
h = waitbar(0,'please wait..');
for i = 1:length(feature(1,:)) % i indicates each of parcel
    waitbar(i/size(feature,2),h,[num2str(i),'/',num2str(size(feature,2))])
    data = feature(:,i);
    if Jloop
        nflod_acu = [];
    else
       nfold_acu = zeros(nfold,1); 
    end
    for j = 1:nfold
        test_idx = (indices == j);
        train_idx = ~test_idx;
        
        train_data = data(train_idx);
        [train_data,PS] = mapminmax(train_data',-1,1); % normalize data
        train_data = train_data';
        train_label = label(train_idx);
        
        test_data = data(test_idx);
        test_data = mapminmax('apply',test_data',PS);  % normalize data
        test_data = test_data';
        test_label = label(test_idx);
        
        nfoldTestLabel = [nfoldTestLabel;test_label];
        
        %%% linear kernal
        [bestacc,bestc] = SVMcgForClass_NoDisplay_linear(train_label,train_data,-10,10,5,0.2);
        cmd = ['-t 0 ', '-h 0 ', ' -c ',num2str(bestc)];
        
        model = svmtrain(train_label,train_data, cmd);
        [predicted_label, accuracy, deci_value] = svmpredict(test_label,test_data,model);
        nfold_parsPredLabel = [nfold_parsPredLabel;predicted_label];
        if Jloop
            nfold_acu = accuracy(1);
            break
        else
            nfold_acu(j) = accuracy(1);
        end
    end
    if Jloop
        parcels_acu(i) = nfold_acu;
    else
        parcels_acu(i) = mean(nfold_acu);
    end
end
close(h)