function [p,ER] = PLS_candidate_genes_ER(PLS,Cgene)
% This function performs permutation test for significance of up/down
% weighting of candidate gene lists in a PLS component
% PLS_geneWeights:the PLS gene weights
% Candidate_genes:the candidate genes
% ABSOLUTE: ABSOLUTE=true for candiate gene set and ABSOLUTE=false for oligo gene set

disp('  Running  enrichment ratio analysis for candidate gene')

PLSweight=PLS.W;
PLSgenes=PLS.gene;

CANDind = [];
for i = 1:length(Cgene) 
    for j = 1:length(PLSgenes)
        if strcmp(Cgene(i),PLSgenes(j))
            CANDind = [CANDind,j];
            break
        end
    end
end

CAND_PLSwe = PLSweight(CANDind);

mean_CAND_PLSw = mean(CAND_PLSwe);

perm_PLSw=[];
for r=1:10000
    permo=randperm(length(PLSgenes));
    tem_PLSw=PLSweight(permo(1:length(Cgene)));
    
    mean_tem_PLSw=mean(tem_PLSw);
    
    perm_PLSw=[perm_PLSw;mean_tem_PLSw];
end
perm_PLSw1 = abs(perm_PLSw);
n = length(find(perm_PLSw1 > abs(mean_CAND_PLSw)));
p = n/length(perm_PLSw1);
p = p/2;
ER = (mean_CAND_PLSw - mean(perm_PLSw)) / std(perm_PLSw);