function [R_pos,P_pos] = changeScore_Corr_Neurosyth(change_score,neurosyth_file,MMP_atla_file)
% This function is to caluculate correlation between change score and
% neuropsychirical probality map acquired form meta analysis in neurosyth website
% INPUTs:
%        change_score - parcel level change score 
%        neurosyth_file - disease pattern file name get from neurosyth(nifti)
%        MMP_atla_file - MMP atlas file name (nifti)
% OUTPUTs:
%        R_pos - the correlation between 
%        P_pos - P value

% load neurosyth_file
neurosyth_nii = load_nii(neurosyth_file);
neurosyth_img = neurosyth_nii.img;
neurosyth_img(neurosyth_img < 0) = 0;

% load MMP atlas
MMP_nii = load_nii(MMP_atla_file);
MMP_img = MMP_nii.img;
MMP_ind = unique(MMP_img);
MMP_ind = MMP_ind(2:end);

% map neurosy value to mmp atlas-left hemisphere
neurosyth_mmp = zeros(length(MMP_ind),1);
for i = 1:length(MMP_ind)
    par_idx = find(MMP_img == MMP_ind(i));
    neurosyth_value = neurosyth_img(par_idx);
    nz_idx = find(neurosyth_value);
    
%     if MMP_ind(i) <= 180
%         neurosyth_value = neurosyth_img(par_idx);
%         nz_idx = find(neurosyth_value);
%     else
%         neurosyth_value = neurosyth_img(par_idx);
%         
%     end
    
    if ~isempty(nz_idx)
    %if length(nz_idx) > 1
        neurosyth_value = neurosyth_value(nz_idx);
        neurosyth_mmp(i) = mean(neurosyth_value);
    else
        continue
    end
end

% correlation analysis
changeScore_pos = change_score;
changeScore_pos(changeScore_pos < 0) = 0;

nz_neu_idx = find(neurosyth_mmp);
neurosyth_mmp_nz = neurosyth_mmp(nz_neu_idx);

changeScore_pos_nz = changeScore_pos(nz_neu_idx);
nz_chanSPos = find(changeScore_pos_nz);
changeScore_pos_nz_nz = changeScore_pos_nz(nz_chanSPos);
neurosyth_mmp_nz_posnz = neurosyth_mmp_nz(nz_chanSPos);
R_pos = corr(neurosyth_mmp_nz_posnz,changeScore_pos_nz_nz);
% neusy_cs = [neurosyth_mmp_nz_posnz,changeScore_pos_nz_nz];

% permutation
R_pos_per = zeros(10000,1);
for i = 1:10000
    
    per_order = randperm(length(change_score));
    changeScore_per = change_score(per_order);
    
    changeScore_pos = changeScore_per;
    changeScore_pos(changeScore_pos < 0) = 0;
    
    changeScore_pos_nz = changeScore_pos(nz_neu_idx);
    nz_chanSPos = find(changeScore_pos_nz);
    changeScore_pos_nz_nz = changeScore_pos_nz(nz_chanSPos);
    neurosyth_mmp_nz_posnz = neurosyth_mmp_nz(nz_chanSPos);
    
    R_pos_per(i) = corr(neurosyth_mmp_nz_posnz,changeScore_pos_nz_nz);
end
P_pos = length(find(abs(R_pos_per)>abs(R_pos))) / 10000;