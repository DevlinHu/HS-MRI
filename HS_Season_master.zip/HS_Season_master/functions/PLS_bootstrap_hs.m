function PLS_Stat = PLS_bootstrap_hs(parcelExpression,GeneSymbol,func_Para)
% Define the PLS bootstrap function with the following arguments
% parcelExpression: used as predictor for plsregression
% GeneSymbol: the txt of gene name
% gmeandiff: used as response valuable for plsregression
% outputdir: the path where to save PLS results

disp('Re-run PLS to get explained variance and associated stats')

%number of bootstrap iterations
bootnum = 1000;

%DO PLS in 2 dimensions (with 2 components)
X = parcelExpression;
Y = zscore(func_Para);
geneindex = 1:length(GeneSymbol);

dim=2;
[XL,YL,XS,YS,BETA,PCTVAR,MSE,stats]=plsregress(X,Y,dim);

%store regions IDs and weights in descending order of weight for both
%components
[R1,p1]=corr([XS(:,1),XS(:,2)],func_Para);

R1_Squ = R1;

PLS_Stat = struct();
PLS_Stat.XS = XS;
%align PLS components with desired direction%
% if R1(1)<0
%     stats.W(:,1)=-1*stats.W(:,1);
%     XS(:,1)=-1*XS(:,1);
% end
% if R1(2)<0
%     stats.W(:,2)=-1*stats.W(:,2);
%     XS(:,2)=-1*XS(:,2);
% end

[PLS1w,x1] = sort(stats.W(:,1),'descend');
PLS1ids=GeneSymbol(x1);
geneindex1=geneindex(x1);
[PLS2w,x2] = sort(stats.W(:,2),'descend');
PLS2ids=GeneSymbol(x2);
geneindex2=geneindex(x2);

%print out results
% save(fullfile(outputdir,'PLS1&2_ROIscores.mat'),'XS')

%define variables for storing the (ordered) weights from all bootstrap runs
PLS1weights=[];
PLS2weights=[];

%start bootstrap
disp('  Bootstrapping - could take a while')
for i=1:bootnum
    myresample = randsample(size(X,1),size(X,1),1);
    res(i,:)=myresample; %store resampling out of interest
    Xr=X(myresample,:); % define X for resampled regions
    Yr=Y(myresample,:); % define Y for resampled regions
    [XL,YL,XS,YS,BETA,PCTVAR,MSE,stats]=plsregress(Xr,Yr,dim); %perform PLS for resampled data
    
    temp=stats.W(:,1);%extract PLS1 weights
    newW=temp(x1); %order the newly obtained weights the same way as initial PLS 
    if corr(PLS1w,newW)<0 % the sign of PLS components is arbitrary - make sure this aligns between runs
        newW=-1*newW;
    end
    PLS1weights=[PLS1weights,newW];%store (ordered) weights from this bootstrap run
    
    temp=stats.W(:,2);%extract PLS2 weights
    newW=temp(x2); %order the newly obtained weights the same way as initial PLS 
    if corr(PLS2w,newW)<0 % the sign of PLS components is arbitrary - make sure this aligns between runs
        newW=-1*newW;
    end
    PLS2weights=[PLS2weights,newW]; %store (ordered) weights from this bootstrap run    
end

%get standard deviation of weights from bootstrap runs
PLS1sw=std(PLS1weights');
PLS2sw=std(PLS2weights');

%get bootstrap weights
temp1=PLS1w./PLS1sw';
temp2=PLS2w./PLS2sw';

%order bootstrap weights (Z) and names of regions
[Z1 ind1]=sort(temp1,'descend');
PLS1=PLS1ids(ind1);
geneindex1=geneindex1(ind1);
[Z2 ind2]=sort(temp2,'descend');
PLS2=PLS2ids(ind2);
geneindex2=geneindex2(ind2);

%print out results
PLS1_Res = struct();
PLS1_Res.gene = PLS1;
PLS1_Res.geneindex1 = geneindex1;
PLS1_Res.W = Z1;

PLS2_Res = struct();
PLS2_Res.gene = PLS2;
PLS2_Res.geneindex1 = geneindex2;
PLS2_Res.W = Z2;

PLS_Stat.pls1 = PLS1_Res;
PLS_Stat.pls2 = PLS2_Res;
PLS_Stat.R_Squ = R1_Squ;
PLS_Stat.func = func_Para;















