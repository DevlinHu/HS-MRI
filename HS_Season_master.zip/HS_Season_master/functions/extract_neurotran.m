function PET_MMP_Value_ALL = extract_neurotran(PET_DIR,mmp_atl1_thd,mmp_img)

PET_MMP_Value_ALL = [];
for i = 1:length(PET_DIR)
    PET_NIFTI = load_nii(PET_DIR(i).name);
    PET_IMG = PET_NIFTI.img;
    PET_MMP_Value = zeros(length(mmp_atl1_thd),1);
    for j = 1:length(mmp_atl1_thd)
        if mmp_atl1_thd(j) <= 180
            subr_ind = find(mmp_img == mmp_atl1_thd(j));
            subr_PET_Value = PET_IMG(subr_ind);
            tmp_ind = find(subr_PET_Value > 0);
            subr_PET_Value = subr_PET_Value(tmp_ind);
            PET_MMP_Value(j) = mean(subr_PET_Value);
        else
            subr_ind = find(mmp_img == (mmp_atl1_thd(j)-180+1000));
            subr_PET_Value = PET_IMG(subr_ind);
            tmp_ind = find(subr_PET_Value > 0);
            subr_PET_Value = subr_PET_Value(tmp_ind);
            PET_MMP_Value(j) = mean(subr_PET_Value);
        end
        
    end
    PET_MMP_Value_ALL = [PET_MMP_Value_ALL,zscore(PET_MMP_Value)];
end