function distributAccu_net = bootstrapAccu_nets(net_label,permute,feature,label)
% This function is to calculate the distribution of classifying accuracy in
% the network level
% Input:
%       net_label: the network index (each parcel identified with an index)
%       permute: the times of the bootstrapped
%       feature: the input feature extracted from functional parameters
%       label: the seasonal labels (Autumn = 1, Winter = 2, Spring = 3, Summer = 4)
% Output:
%        distributAccu_net: the distribution of the accuracy

nfold = 10;
Jloop = 1;
distributAccu_net = [];

CoreNum = 8; % the number of core was used
if isempty(gcp)
    parpool(CoreNum)
end
hbar = parfor_progressbar(permute,'Please wait...'); % creat the progress bar
parfor i = 1:permute
    randIDX = randperm(length(label));
    featurePerm = feature(randIDX(1:ceil(length(label)/2)),:); % take half of features
    labelPerm = label(randIDX(1:ceil(length(label)/2)));
    [nets_Acu,~,~] = networkLevel_SVM(net_label,featurePerm,labelPerm,nfold,Jloop);
    distributAccu_net = [distributAccu_net,nets_Acu];
    hbar.iterate(1);
end
close(hbar); % Clean up
