function net_lable_shuff = shuffleNetwork(net_label)
% This function is to shuffle the parcels in each network across the whole
% brain
% Input
%       net_lable: the network
% Output
%       shuffNetLable: the shuffle network
regiontoNet_id = zeros(size(net_label,1),1);
for i = 1:size(net_label,1)
    regiontoNet_id(i) = net_label{i,2};
end
net_id = unique(regiontoNet_id);
clear i

net_lable_shuff = cell(size(net_label));
numOfPars = size(net_label,1)/2;
L_regiontoNet_id = regiontoNet_id(1:numOfPars);
R_regiontoNet_id = regiontoNet_id(numOfPars+1:end);
region_id = zeros(size(net_label,1),1);
for i = 1:length(net_id)
    shulffIDX1 = randperm(numOfPars);
    shulffIDX2 = shulffIDX1 + numOfPars;
    L_net_IDX = find(L_regiontoNet_id == net_id(i));
    R_net_IDX = find(R_regiontoNet_id == net_id(i));
    R_net_IDX = R_net_IDX + numOfPars;
    region_id(L_net_IDX) = shulffIDX1(1:length(L_net_IDX));
    region_id(R_net_IDX) = shulffIDX2(1:length(R_net_IDX));
end
clear i

for i = 1:size(net_label,1)
    net_lable_shuff{i,1} = region_id(i);
    net_lable_shuff{i,2} = net_label{i,2};
    net_lable_shuff{i,3} = net_label{i,3};
end