function PLS_calculate_stats_hs(parcelExpression_thd,parcelExpression,func_Para_thd,outputdir)
% Define the PLS calculate function with the following arguments
% parcelExpression: used as predictor for plsregression
% func_Para: used as response valuable for plsregression
% outputdir: the path where to save PLS results

disp('Re-run PLS to get explained variance and associated stats')

%DO PLS in 2 dimensions (with 2 components)
X = parcelExpression_thd;
Y = func_Para_thd;

dim = 10;
dim1=2;
[XL,YL,XS,YS,BETA,PCTVAR,MSE,stats]=plsregress(X,Y,dim);

temp=cumsum(100*PCTVAR(2,1:dim1));
Rsquared = temp(dim1);
PCTVAR = PCTVAR(2,:);

%assess significance of PLS result
PCTVAR_PEM = [];
for j=1:1000
    order=randperm(size(parcelExpression,1));

    parcelExpression_tmp = parcelExpression(order,:);
    Xp = parcelExpression_tmp(1:size(Y,1),:);

    [XLr,YLr,XSr,YSr,BETAr,PCTVARr,MSEr,statsr]=plsregress(Xp,Y,dim);
    temp=cumsum(100*PCTVARr(2,1:dim1));
    Rsq(j) = temp(dim1);
    PCTVAR_PEM = [PCTVAR_PEM;PCTVARr(2,:)];

end
p=length(find(Rsq>=Rsquared))/j;

%save stats
myStats = struct();
myStats.P = p;
myStats.R_squ_perm = Rsq;
myStats.R_squ = Rsquared;
save(fullfile(outputdir,'myStats1124.mat'),'myStats');

EXPVAR = struct();
EXPVAR.PCTVAR = PCTVAR;
EXPVAR.PCTVAR_PEM = PCTVAR_PEM;
save(fullfile(outputdir,'EXPVAR.mat'),'EXPVAR');






