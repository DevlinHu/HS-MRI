function [net_label_Shuff,net_Acu_Shuff,change_score_perm]=controlNetwork(MMP_network,feature,label,shull_ture,changeScore_done,outputDIR)

CoreNum = 8; % the number of core was used
if isempty(gcp)
    parpool(CoreNum)
end

if shull_ture
    nfold = 10;
    Jloop = 0;

    net_Acu_Shuff = [];
    permute1 = 1000;
    net_label_Shuff = cell(permute1,1);

    hbar = parfor_progressbar(permute1,'Please wait shuffle Acu...'); % creat the progress bar
    parfor i = 1:permute1
        net_label = shuffleNetwork(MMP_network);
        [nets_Acu_Rand,~,~] = networkLevel_SVM(net_label,feature,label,nfold,Jloop);
        net_label_Shuff{i} = net_label;
        net_Acu_Shuff = [net_Acu_Shuff,nets_Acu_Rand];
        hbar.iterate(1);
    end
    save(fullfile(outputDIR,'net_label_Shuff.mat'),'net_label_Shuff')
    save(fullfile(outputDIR,'net_Acu_Shuff.mat'),'net_Acu_Shuff')
    close(hbar); % Clean up
    clear i nfold Jloop hbar
else
     load net_label_Shuff.mat
     load net_Acu_Shuff.mat
end

if changeScore_done
    nfold = 5;
    Jloop = 1;
    permute1 = length(net_label_Shuff);
    shulff_rand = randperm(permute1);
    permute2 = 1000;

    hbar = parfor_progressbar(permute2,'Permute change score...'); % creat the progress bar
    change_score_perm = [];
    parfor i = 1:permute2
        randIDX = randperm(length(label));
        feature_perm = feature(randIDX,:);
        change_score_shuff = [];
        for j = 1:(permute1/4)
            [nets_acu_rand,~,~] = networkLevel_SVM(net_label_Shuff{shulff_rand(j)},feature_perm,label,nfold,Jloop);
            change_score = net_Acu_Shuff(:,shulff_rand(j))-nets_acu_rand;
            change_score_shuff = [change_score_shuff,change_score];
        end
        change_score_perm = [change_score_perm,mean(change_score_shuff,2)];
        hbar.iterate(1);
    end
    save(fullfile(outputDIR,'net8_change_score_perm.mat'),'change_score_perm')
    close(hbar); % Clean up
else
    change_score_perm = [];
end




