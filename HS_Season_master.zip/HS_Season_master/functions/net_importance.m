function change_score_perm = net_importance(nets_acu,net_label,permute,feature,label)
% This function is to calculate network importance in classification of
% season
% Input:
%       nets_acu: the accuracy of the seasonal classification
%       permute: the number of the petmutation
%       feature: the input feature extracted from functional parameters
%       label: the seasonal labels (Autumn = 1, Winter = 2, Spring = 3, Summer = 4)
% Output:
%        change_score: the accuray munus the permuted accuracy


% rand_ACU = [];
change_score_perm = [];
CoreNum = 10; % the number of core was used
if isempty(gcp)
    parpool(CoreNum)
end

hbar = parfor_progressbar(permute,'Please wait...'); % creat the progress bar
parfor i = 1:permute
    randIDX = randperm(length(label));
    feature_perm = feature(randIDX,:);
    [nets_acu_rand,~,~] = networkLevel_SVM(net_label,feature_perm,label,10,1);
    % rand_ACU = [rand_ACU,nets_acu_perm];
    change_score = nets_acu-nets_acu_rand;
    change_score_perm = [change_score_perm,change_score];
    hbar.iterate(1);
end
close(hbar); % Clean up