function change_score_perm = parcel_importance(parcels_acu,permute,feature,label)
% This function is to calculate parcel importance in classification of
% season
% Input:
%       parcels_acu: the accuracy of the seasonal classification
%       permute: the number of the petmutation
%       feature: the input feature extracted from functional parameters
%       label: the seasonal labels (Autumn = 1, Winter = 2, Spring = 3, Summer = 4)
% Output:
%        change_score: the accuray munus the permuted accuracy

% rand_ACU = [];
change_score_perm = [];

CoreNum = 8; % the number of core was used
if isempty(gcp)
    parpool(CoreNum)
end
hbar = parfor_progressbar(permute,'Please wait...'); % creat the progress bar
parfor i = 1:permute
    randIDX = randperm(length(label));
    feature_perm = feature(randIDX,:);
    [parcels_acu_rand,~,~] = parcelLevel_SVM(feature_perm,label,10,1);
    change_score = parcels_acu-parcels_acu_rand;
    change_score_perm = [change_score_perm,change_score];
    hbar.iterate(1);
end
close(hbar); % Clean up
% change_score = parcels_acu - mean(rand_ACU,2);